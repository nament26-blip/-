"use client";

import React, { useState } from "react";
import {
  Star, ShieldCheck, MapPin, Video, GraduationCap,
  BadgeCheck, Clock, Globe, ChevronDown, Heart, ChevronLeft
} from "lucide-react";

const PSYCHOLOGIST = {
  name: "Анна Соколова",
  role: "КПТ-терапевт",
  experience: 8,
  rating: 4.9,
  reviewsCount: 132,
  price: 40,
  city: "Алматы",
  formats: ["Онлайн", "Очно"],
  languages: ["Русский", "Английский"],
  methods: ["КПТ", "Схема-терапия"],
  requests: ["Тревога", "Отношения", "Самооценка", "Панические атаки"],
  about:
    "Работаю с тревожными состояниями, паническими атаками и трудностями в отношениях. " +
    "Опираюсь на когнитивно-поведенческий подход — вместе разбираем конкретную ситуацию, " +
    "находим закономерности и учимся с ними обращаться на практике, а не только в разговоре.",
  education: [
    { title: "МГУ им. Ломоносова, факультет психологии", years: "2012–2017" },
    { title: "Сертификация по КПТ, Ассоциация когнитивно-поведенческой психотерапии", years: "2018" },
    { title: "Схема-терапия, повышение квалификации", years: "2021" },
  ],
  reviews: [
    { name: "Мадина К.", rating: 5, text: "Очень бережно и по делу. После трёх сессий стало заметно спокойнее переносить рабочие созвоны.", date: "2 недели назад" },
    { name: "Тимур А.", rating: 5, text: "Анна умеет слушать и не давит. Дала конкретные техники, которые правда работают.", date: "месяц назад" },
    { name: "Ольга П.", rating: 4, text: "Хороший специалист, иногда сессии кажутся короткими — но в целом результат есть.", date: "2 месяца назад" },
  ],
};

const ratingBreakdown = [
  { stars: 5, pct: 82 },
  { stars: 4, pct: 13 },
  { stars: 3, pct: 3 },
  { stars: 2, pct: 1 },
  { stars: 1, pct: 1 },
];

function Section({ title, children }) {
  return (
    <section className="border-t border-stone-200 py-8 first:border-t-0 first:pt-0">
      <h2 className="font-display text-xl text-stone-900">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export default function PsychologistProfilePage({ params }) {
  // params.id — идентификатор специалиста из URL /psychologist/[id];
  // в этом демо-скелете подставляются моковые данные PSYCHOLOGIST,
  // в реальном проекте здесь будет запрос к API по params.id.
  const [aboutExpanded, setAboutExpanded] = useState(false);
  const [saved, setSaved] = useState(false);
  const p = PSYCHOLOGIST;

  return (
    <div className="font-body min-h-screen bg-stone-50 text-stone-800">

      {/* TOP BAR */}
      <div className="border-b border-stone-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-5">
          <a href="/catalog" className="flex items-center gap-2 text-sm font-medium text-stone-500 hover:text-stone-700">
            <ChevronLeft size={16} /> К каталогу
          </a>
          <div className="font-display text-xl text-emerald-800">тепло</div>
        </div>
      </div>

      <div className="mx-auto grid max-w-5xl grid-cols-1 gap-10 px-6 py-10 lg:grid-cols-[1fr_360px]">
        {/* LEFT: PROFILE */}
        <div>
          {/* Profile header */}
          <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
            <div className="relative h-40 w-40 shrink-0 overflow-hidden rounded-3xl bg-gradient-to-br from-sky-100 to-emerald-50 sm:h-48 sm:w-48">
              <button
                onClick={() => setSaved(!saved)}
                className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-stone-500 hover:text-rose-500"
                aria-label="Сохранить в избранное"
              >
                <Heart size={18} className={saved ? "fill-rose-500 text-rose-500" : ""} />
              </button>
              <span className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-white/90 px-3 py-1.5 text-xs font-medium text-emerald-800">
                <ShieldCheck size={13} /> Проверено
              </span>
            </div>

            <div className="flex-1">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <h1 className="font-display text-3xl text-stone-900">{p.name}</h1>
                  <p className="mt-1 text-stone-500">{p.role} · {p.experience} лет практики</p>
                </div>
                <div className="flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-sm shadow-sm">
                  <Star size={16} className="fill-amber-500 text-amber-500" />
                  <span className="font-semibold text-stone-800">{p.rating}</span>
                  <span className="text-stone-400">({p.reviewsCount} отзывов)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-1.5">
            {p.requests.map((r) => (
              <span key={r} className="rounded-full bg-stone-100 px-3 py-1 text-xs text-stone-600">{r}</span>
            ))}
          </div>

          <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-stone-500">
            <span className="flex items-center gap-1.5"><MapPin size={15} /> {p.city}</span>
            <span className="flex items-center gap-1.5"><Video size={15} /> {p.formats.join(" · ")}</span>
            <span className="flex items-center gap-1.5"><Globe size={15} /> {p.languages.join(", ")}</span>
            <span className="flex items-center gap-1.5"><BadgeCheck size={15} /> {p.methods.join(", ")}</span>
          </div>

          <Section title="О специалисте">
            <p className={`leading-relaxed text-stone-600 ${aboutExpanded ? "" : "line-clamp-3"}`}>
              {p.about}
            </p>
            <button
              onClick={() => setAboutExpanded(!aboutExpanded)}
              className="mt-2 flex items-center gap-1 text-sm font-semibold text-emerald-700"
            >
              {aboutExpanded ? "Свернуть" : "Читать полностью"}
              <ChevronDown size={14} className={aboutExpanded ? "rotate-180" : ""} />
            </button>
          </Section>

          <Section title="Образование и сертификаты">
            <div className="space-y-4">
              {p.education.map((e) => (
                <div key={e.title} className="flex gap-3">
                  <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-700">
                    <GraduationCap size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-stone-800">{e.title}</p>
                    <p className="text-xs text-stone-500">{e.years}</p>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          <Section title={`Отзывы клиентов (${p.reviewsCount})`}>
            <div className="mb-6 flex flex-col gap-6 sm:flex-row sm:items-center">
              <div className="text-center">
                <p className="font-display text-4xl text-stone-900">{p.rating}</p>
                <div className="mt-1 flex justify-center gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={14} className="fill-amber-500 text-amber-500" />
                  ))}
                </div>
                <p className="mt-1 text-xs text-stone-500">{p.reviewsCount} отзывов</p>
              </div>
              <div className="flex-1 space-y-1.5">
                {ratingBreakdown.map((r) => (
                  <div key={r.stars} className="flex items-center gap-2 text-xs text-stone-500">
                    <span className="w-3">{r.stars}</span>
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-stone-100">
                      <div className="h-full rounded-full bg-amber-400" style={{ width: `${r.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-5">
              {p.reviews.map((r) => (
                <div key={r.name} className="rounded-2xl border border-stone-200 p-5">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold text-stone-800">{r.name}</p>
                    <span className="text-xs text-stone-400">{r.date}</span>
                  </div>
                  <div className="mt-1 flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} size={12} className={i < r.rating ? "fill-amber-500 text-amber-500" : "text-stone-200"} />
                    ))}
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-stone-600">{r.text}</p>
                </div>
              ))}
            </div>
          </Section>
        </div>

        {/* RIGHT: STICKY BOOKING CARD */}
        <aside className="h-fit lg:sticky lg:top-8">
          <div className="rounded-3xl border border-stone-200 bg-white p-6 shadow-sm">
            <div className="flex items-baseline justify-between">
              <span className="font-display text-2xl text-stone-900">${p.price}</span>
              <span className="text-sm text-stone-400">/ сессия 50 мин</span>
            </div>

            <div className="mt-4 flex items-center gap-2 text-sm text-stone-500">
              <Clock size={15} /> Ближайший слот — сегодня, 18:30
            </div>

            <button className="mt-5 w-full rounded-full bg-emerald-700 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-emerald-800">
              Записаться на сессию
            </button>
            <button className="mt-3 w-full rounded-full border border-stone-200 py-3.5 text-sm font-semibold text-stone-700 transition-colors hover:bg-stone-50">
              Написать сообщение
            </button>

            <p className="mt-4 text-center text-xs text-stone-400">
              Бесплатная отмена или перенос за 24 часа до сессии
            </p>
          </div>

          <div className="mt-4 rounded-3xl bg-emerald-50 p-5 text-sm text-emerald-900">
            <p className="flex items-center gap-2 font-semibold">
              <ShieldCheck size={16} /> Гарантия платформы
            </p>
            <p className="mt-1.5 text-emerald-800/80">
              Если первая сессия не подошла — поможем бесплатно подобрать другого специалиста.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}
