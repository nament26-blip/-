import { Fraunces, Manrope } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-fraunces",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata = {
  title: "тепло — платформа поиска психологов",
  description: "Найдите психолога по запросу, бюджету, методу терапии и языку сессии.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru" className={`${fraunces.variable} ${manrope.variable}`}>
      <body className="bg-stone-50 text-stone-800 antialiased">{children}</body>
    </html>
  );
}
